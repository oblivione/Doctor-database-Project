-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2014 at 03:39 AM
-- Server version: 5.1.72-community
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project6`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE IF NOT EXISTS `clinic` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `facilities_available` varchar(200) NOT NULL,
  `avg_patient_seen` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `average_turnover` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`Id`, `Name`, `location`, `facilities_available`, `avg_patient_seen`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `average_turnover`, `any_other`) VALUES
(3, 'Maheswata LABS', 'M-125 Kalinga Vihar Chhend Colony Rourkela', 'OPD', '', 'Maheswata', '9853034348   ', 'swaynjtmshr77@gmail.com', '1997', '2000', 'Demo1'),
(4, 'Test1', 'test1   ', 'test1    ', '0', 'test1', 'test1   ', 'test1', 'test1', 'test1', 'test1');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `clinic` varchar(200) NOT NULL,
  `clinic_timing_from` varchar(200) NOT NULL,
  `clinic_timing_to` varchar(200) NOT NULL,
  `organisation` varchar(200) NOT NULL,
  `specialisation` varchar(200) NOT NULL,
  `avg_patient_seen` varchar(11) NOT NULL,
  `hospital_name` varchar(200) NOT NULL,
  `hospital_timing_from` varchar(200) NOT NULL,
  `hospital_timing_to` varchar(200) NOT NULL,
  `qualification` varchar(200) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `location` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  `picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Id`, `Name`, `clinic`, `clinic_timing_from`, `clinic_timing_to`, `organisation`, `specialisation`, `avg_patient_seen`, `hospital_name`, `hospital_timing_from`, `hospital_timing_to`, `qualification`, `mobile_number`, `email`, `dob`, `location`, `any_other`, `picture`) VALUES
(3, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(4, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(5, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(6, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '0', 'Vesaj Patel', '', '', '', '', '', '2014-03-08', 'Chhend Colony Rourkela', '', ''),
(7, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(8, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(9, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(10, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(11, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(12, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(13, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(14, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(15, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(16, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(17, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(18, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(19, 'Chandan Bansal', 'Maheswata LABS', '', '', '', 'Medicine Heart ', '4', 'Vesaj Patel', '', '', '', '', '', '2014-03-18', '', '', ''),
(22, 'S.K.Sarangi', ',,,,', ',,,,', ',,,,', '', 'Md,,,', '4', ',,,,', ',,,,', ',,,,', '', '', '', '2014-03-05', ',,,,', '', 'demo.jpg'),
(23, 'Swayan Jeet', 'Maheswata LABS,,,,', '10,,,,', '11,,,,', '', 'Skin,,,', '4', 'Vesaj Patel,,,,', '8,,,,', '8,,,,', 'MBBS', '9853034348', 'swayanjeetmshr657@gmail.com', '2014-03-01', 'Pl-e-143 Chhend Colony', 'Demo', ''),
(24, 'Demo', 'Maheswata LABS,,,,', '10,,,,', '11,,,,', '', 'Demo,,,', '1', 'Vesaj Patel,,,,', '8,,,,', '9,,,,', 'MBBS', '999', 'demo', '2014-03-01', 'Demo,,,,', 'Demo', ''),
(25, 'demo', 'Maheswata LABS,,,,', '11,,,,', '12,,,,', '', 'demo,,,', '1', 'Vesaj Patel,,,,', '9,,,,', '11,,,,', 'MBBS', 'DEMO', 'DEMO', '2014-03-01', 'DEMO,,,,', 'DEMO', 'x.jpg'),
(26, 'Demo', 'Test1,,,,', '11,,,,', '12,,,,', '', ',,,', '1', 'demo,,,,', '11,,,,', '12,,,,', '', '', '', '2014-03-01', ',,,,', '', 'demo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE IF NOT EXISTS `drugs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`Id`, `Name`) VALUES
(1, 'nicil');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `bed_numbers` varchar(100) NOT NULL,
  `kind_of_bed` varchar(100) NOT NULL,
  `facilities_available` varchar(200) NOT NULL,
  `opd_unit` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `insurance_company` varchar(200) NOT NULL,
  `average_turnover` varchar(200) NOT NULL,
  `average_bed_occupancy` varchar(200) NOT NULL,
  `average_rate` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`Id`, `Name`, `location`, `bed_numbers`, `kind_of_bed`, `facilities_available`, `opd_unit`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `insurance_company`, `average_turnover`, `average_bed_occupancy`, `average_rate`, `any_other`, `Picture`) VALUES
(2, 'Vesaj Patel', 'Civil Township   ', '13', 'Single Non AC Single AC Double Non AC', 'Health Care', '10', 'Swayan Jeet', '9853034348', 'swayanjeetmshr657@gmail.com', '1990', 'Demo', '25000', '10', '250,260', 'Demo1', ''),
(3, 'demo', 'demo   ', 'demo', 'demo  ', 'demo    ', 'demo', 'demo', 'demo', 'dmeo', 'demo', 'dmo    ', 'demo', 'demo', '150 200', 'deom', 'demo2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE IF NOT EXISTS `invoices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_Name` varchar(200) NOT NULL,
  `Item_Name` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`Id`, `Vendor_Name`, `Item_Name`, `Description`, `Price`, `Date`, `Picture`) VALUES
(1, 'Indian Medical Association', 'Laptop', 'I-5 Processor        ', '31000', '2014-03-01', 'Imperial_State_Crown2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Id`, `Name`) VALUES
(1, 'Laptop'),
(5, 'funky');

-- --------------------------------------------------------

--
-- Table structure for table `organisation`
--

CREATE TABLE IF NOT EXISTS `organisation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `organisation`
--

INSERT INTO `organisation` (`Id`, `Name`, `location`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `any_other`) VALUES
(2, 'Indian Medical Association', 'New Delhi   ', 'Sarwar Hasib', '9853034349', 'swayanjeetmshr657@gmail.com', '1995', 'Demo1'),
(3, 'test1', 'test1   ', 'test1', 'test1   ', 'test1', 'test1', 'test2');

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE IF NOT EXISTS `others` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `facilities_available` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `average_turnover` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `others`
--

INSERT INTO `others` (`Id`, `Name`, `location`, `facilities_available`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `average_turnover`, `any_other`) VALUES
(1, 'Indian Medical Association', 'New Delhi   ', 'OPD', 'Sarwar Hasib', '9853034348   ', 'swayanjeetmshr657@gmail.com', '1995', '400000', 'Demo'),
(2, 'Indian Medical Association', 'New Delhi   ', 'OPD', 'Sarwar Hasib', '9853034348   ', 'swayanjeetmshr657@gmail.com', '1995', '400000', 'Demo');

-- --------------------------------------------------------

--
-- Table structure for table `pharmaceuticals`
--

CREATE TABLE IF NOT EXISTS `pharmaceuticals` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `facilities_available` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `average_turnover` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `pharmaceuticals`
--

INSERT INTO `pharmaceuticals` (`Id`, `Name`, `location`, `facilities_available`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `average_turnover`, `any_other`) VALUES
(2, 'Indian Medical Association', 'New Delhi   ', 'OPD', 'Sarwar Hasib', '9853034348   ', 'swayanjeetmshr657@gmail.com', '1995', '400000', 'Demo'),
(3, 'Aswini', 'VSS Market Chhend Colony Rourkela ', 'Medicine and Amublance', 'Aswini Mohapatra', '8895617737   ', 'swaynjtmshr77@gmail.com', '1990', '6000', 'Demo1');

-- --------------------------------------------------------

--
-- Table structure for table `pharma_invoices`
--

CREATE TABLE IF NOT EXISTS `pharma_invoices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_Name` varchar(200) NOT NULL,
  `Item_Name` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pharma_invoices`
--

INSERT INTO `pharma_invoices` (`Id`, `Vendor_Name`, `Item_Name`, `Description`, `Price`, `Date`, `Picture`) VALUES
(1, 'Demo', 'Demo', 'Demo    ', 'Demo', '2014-03-01', 'demo1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pharma_quotations`
--

CREATE TABLE IF NOT EXISTS `pharma_quotations` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_Name` varchar(200) NOT NULL,
  `Item_Name` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pharma_quotations`
--

INSERT INTO `pharma_quotations` (`Id`, `Vendor_Name`, `Item_Name`, `Description`, `Price`, `Date`, `Picture`) VALUES
(1, 'Test', 'Test', 'demo    ', 'DEMO', '2014-03-07', 'demo1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE IF NOT EXISTS `quotations` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_Name` varchar(200) NOT NULL,
  `Item_Name` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `Date` date NOT NULL,
  `Picture` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`Id`, `Vendor_Name`, `Item_Name`, `Description`, `Price`, `Date`, `Picture`) VALUES
(2, 'Lyonzone', 'Computers', 'Demo    ', '120', '2014-03-20', ''),
(3, 'Lyonzone', 'demo', 'demo    ', '120', '2014-03-07', ''),
(4, 'Demo', 'Demo', 'Demo    ', '120', '2014-03-07', ''),
(5, 'Demo', 'Demo', 'Demo    ', '130', '2014-03-14', ''),
(6, 'Demo', 'Demo', 'Demo    ', '130', '2014-03-14', ''),
(7, 'demo', 'demo', 'demo    ', '120', '2014-03-01', ''),
(9, 'test', 'test', 'test    ', '120', '2014-03-01', 'template'),
(10, 'test1', 'test1', 'test1    ', '120', '2014-03-02', 'template'),
(11, 'test2', 'test2', 'test2    ', '140', '2014-03-08', 'template'),
(12, '4', '4', '4    ', '8', '2014-03-13', 'Imperial_State_Crown2.jpg'),
(13, 'Kushals Furnitures', 'Laptop', 'I-5 Processor    ', '130', '2014-03-01', 'CP.jpg'),
(14, 'test5', 'test5', 'test5    ', 'test5', '2014-03-07', 'demo1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `uc_configuration`
--

CREATE TABLE IF NOT EXISTS `uc_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `value` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `uc_configuration`
--

INSERT INTO `uc_configuration` (`id`, `name`, `value`) VALUES
(1, 'website_name', 'UserCake'),
(2, 'website_url', 'localhost/Theme/'),
(3, 'email', 'noreply@ILoveUserCake.com'),
(4, 'activation', 'false'),
(5, 'resend_activation_threshold', '0'),
(6, 'language', 'models/languages/en.php'),
(7, 'template', 'models/site-templates/default.css');

-- --------------------------------------------------------

--
-- Table structure for table `uc_pages`
--

CREATE TABLE IF NOT EXISTS `uc_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(150) NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `uc_pages`
--

INSERT INTO `uc_pages` (`id`, `page`, `private`) VALUES
(1, 'account.php', 1),
(2, 'activate-account.php', 0),
(3, 'admin_configuration.php', 1),
(4, 'admin_page.php', 1),
(5, 'admin_pages.php', 1),
(6, 'admin_permission.php', 1),
(7, 'admin_permissions.php', 1),
(8, 'admin_user.php', 1),
(9, 'admin_users.php', 1),
(10, 'forgot-password.php', 0),
(11, 'index.php', 0),
(12, 'left-nav.php', 0),
(13, 'login.php', 0),
(14, 'logout.php', 1),
(15, 'register.php', 0),
(16, 'resend-activation.php', 0),
(17, 'user_settings.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `uc_permissions`
--

CREATE TABLE IF NOT EXISTS `uc_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `uc_permissions`
--

INSERT INTO `uc_permissions` (`id`, `name`) VALUES
(1, 'New Member'),
(2, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `uc_permission_page_matches`
--

CREATE TABLE IF NOT EXISTS `uc_permission_page_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `uc_permission_page_matches`
--

INSERT INTO `uc_permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(1, 1, 1),
(2, 1, 14),
(3, 1, 17),
(4, 2, 1),
(5, 2, 3),
(6, 2, 4),
(7, 2, 5),
(8, 2, 6),
(9, 2, 7),
(10, 2, 8),
(11, 2, 9),
(12, 2, 14),
(13, 2, 17);

-- --------------------------------------------------------

--
-- Table structure for table `uc_users`
--

CREATE TABLE IF NOT EXISTS `uc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `display_name` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email` varchar(150) NOT NULL,
  `activation_token` varchar(225) NOT NULL,
  `last_activation_request` int(11) NOT NULL,
  `lost_password_request` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `title` varchar(150) NOT NULL,
  `sign_up_stamp` int(11) NOT NULL,
  `last_sign_in_stamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `uc_users`
--

INSERT INTO `uc_users` (`id`, `user_name`, `display_name`, `password`, `email`, `activation_token`, `last_activation_request`, `lost_password_request`, `active`, `title`, `sign_up_stamp`, `last_sign_in_stamp`) VALUES
(1, 'swayanjeetmshr657', 'SwayanJeet', '026c3eb578c02c4850008cbff50e328bd78364bedcda639817d091740b006f01d', 'swayanjeetmshr669@gmail.com', '9c01e3c02cdb9922fe967833403a854c', 1393566194, 0, 1, 'New Member', 1393566194, 1395457647);

-- --------------------------------------------------------

--
-- Table structure for table `uc_user_permission_matches`
--

CREATE TABLE IF NOT EXISTS `uc_user_permission_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `uc_user_permission_matches`
--

INSERT INTO `uc_user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(1, 1, 2),
(2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE IF NOT EXISTS `vendor` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `facilities_available` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `contact_details` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `year_of_establishment` varchar(200) NOT NULL,
  `average_turnover` varchar(200) NOT NULL,
  `any_other` varchar(200) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`Id`, `Name`, `location`, `facilities_available`, `owner_name`, `contact_details`, `email`, `year_of_establishment`, `average_turnover`, `any_other`) VALUES
(2, 'Indian Medical Association', 'New Delhi   ', 'OPD', 'Sarwar Hasib', '9853034348   ', 'swayanjeetmshr657@gmail.com', '1995', '400000', 'Demo'),
(3, 'Kushals Furnitures', 'Uditnagar Rourkela  ', 'Furniture', 'Kushal Goel', '9937469389   ', 'swayanjeetmshr657@gmail.com', '1998', '60000', 'Demo1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
