<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
echo "
<img src='assets/images/login-bg.png' class='login-img' alt=''>
<div class='ui-widget-overlay bg-black opacity-60'></div>
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='login-page'>
    <form action='".$_SERVER['PHP_SELF']."' method='post'>

        <div class='ui-dialog col-md-4 center-margin form-vertical modal-dialog' id='login-form'>
            <div class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix'>
                <span class='ui-dialog-title'>Doctor's Database</span>
            </div>
            <div class='pad20A pad0B ui-dialog-content ui-widget-content'>
               ";
				echo "
                


          
            </div>
            

      
            </div>
        </div>

    </form>

</div>";


echo "
</body>
</html>";
?>
