<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Add Organisations
    <small>
        Add details of the organisation
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_POST))
{
$organisation_name=$_POST['organisation_name'];	
$location=$_POST["location"];
$owner_name=$_POST['owner_name'];
$contacts=$_POST["contacts"];
$email=$_POST['email'];
$year_of_establishment=$_POST['year_of_establishment'];
$any_other=$_POST['any_other'];
$locations=implode(' ',$location);
$contacts=implode(' ',$contacts);
$con=connection();
$query="INSERT INTO organisation (Name, location, owner_name, contact_details, email, year_of_establishment, any_other) VALUES ('$organisation_name', '$locations', '$owner_name', '$contacts', '$email', '$year_of_establishment', '$any_other')";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Organisation has been added.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
echo "
<div id='regbox'>
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='organisation_name' id='organisation_name'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       Location :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                      Name of President/Head :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <input type='text' name='owner_name' id='owner_name'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Contact Details :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts[]' id='contacts[]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts[]' id='contacts[]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                    
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts[]' id='contacts[]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                    
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts[]' id='contacts[]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Email :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='email' id='email'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Year of Establishment :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='year_of_establishment' id='year_of_establishment'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Any Other :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='any_other' id='any_other'>
                </div>
            </div>
<button class='btn primary-bg medium'>
            <span class='button-content'>Save</span>
        </button>

</form>
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
