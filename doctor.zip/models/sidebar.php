<?php
echo "
<div id='page-sidebar' class='scrollable-content'>

                <div id='sidebar-menu'>
                    <ul>
                        <li>
                            <a href='account.php' title='Dashboard'>
                                <i class='glyph-icon icon-dashboard'></i>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href='javascript:;' title='Doctor Details'>
                                <i class='glyph-icon icon-code'></i>
                                Doctor Details
                            </a>
                            <ul>
                                <li>
                                    <a href='doctor.php' title='Add Doctor'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add a Doctor
                                    </a>
                                </li>
                                <li>
                                    <a href='search_doctor.php' title='Search Doctor'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search Doctor
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href='javascript:;' title='Pages'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Hospital Details
                            </a>
                            <ul>
                                <li>
                                    <a href='hospital.php' title='Add Hospital'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New Hospital
                                    </a>
                                </li>
                                <li>
                                    <a href='search_hospital.php' title='Search Hospital'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search Hospital
                                    </a>
                                </li>
                            </ul>
                        </li>
						 <li>
                            <a href='javascript:;' title='Organisations'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Organisational Details
                            </a>
                            <ul>
                                <li>
                                    <a href='organisation.php' title='Add Organisation'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New Organisation
                                    </a>
                                </li>
                                <li>
                                    <a href='search_organisation.php' title='Search Hospital'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search Organisation
                                    </a>
                                </li>
                            </ul>
                        </li>
                         <li>
                            <a href='javascript:;' title='Clinic'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Clinic
                            </a>
                            <ul>
                                <li>
                                    <a href='labs.php' title='Add Clinic'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New Clinic
                                    </a>
                                </li>
                                <li>
                                    <a href='search_clinic.php' title='Search Clinic'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search Clinic
                                    </a>
                                </li>
                            </ul>
                        </li>
						 <li>
                            <a href='javascript:;' title='Vendors'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Vendor
                            </a>
                            <ul>
                                <li>
                                    <a href='vendors.php' title='Add Vendor'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New Vendor
                                    </a>
                                </li>
								<li>
                                    <a href='quotation.php' title='Add Quotation'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Quotations
                                    </a>
                                </li>
								<li>
                                    <a href='invoices.php' title='Add Quotation'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Invoices
                                    </a>
                                </li>
                                <li>
                                    <a href='search_vendor.php' title='Search Clinic'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search Vendor
                                    </a>
                                </li>
                            </ul>
                        </li>
						<li>
                            <a href='javascript:;' title='Pharmaceuticals'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Pharmaceuticals
                            </a>
                            <ul>
                                <li>
                                    <a href='pharmaceuticals.php' title='Add'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New 
                                    </a>
                                </li>
								<li>
                                    <a href='pharma_quotation.php' title='Add Quotation'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Quotations
                                    </a>
                                </li>
								<li>
                                    <a href='pharma_invoices.php' title='Add Quotation'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Invoices
                                    </a>
                                </li>
                                <li>
                                    <a href='search_pharmaceuticals.php' title='Search'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search 
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
						 <li>
                            <a href='javascript:;' title='Others'>
                                <i class='glyph-icon icon-folder-open'></i>
                                Others
                            </a>
                            <ul>
                                <li>
                                    <a href='others.php' title='Add'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Add New 
                                    </a>
                                </li>
                                <li>
                                    <a href='search_others.php' title='Search'>
                                        <i class='glyph-icon icon-chevron-right'></i>
                                        Search 
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <div class='divider mrg5T mobile-hidden'></div>
                    <div class='text-center mobile-hidden'>
                        <div class='button-group display-inline'>
                            <a href='javascript:;' class='btn medium bg-green tooltip-button' data-placement='top' title='Messages'>
                                <i class='glyph-icon icon-flag'></i>
                            </a>
                            <a href='javascript:;' class='btn medium bg-green tooltip-button' data-placement='top' title='Mailbox'>
                                <i class='glyph-icon icon-inbox'></i>
                            </a>
                            <a href='javascript:;' class='btn medium bg-green tooltip-button' data-placement='top' title='Content'>
                                <i class='glyph-icon icon-hdd'></i>
                            </a>
                        </div>

                    </div>
                </div>

            </div><!-- #page-sidebar -->
            ";
			?>