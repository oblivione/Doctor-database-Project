<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Delete Hospital
    <small>
        Delete the Detials of the Hospital
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_POST))
{
$Id=$_POST['Id'];
$con=connection();
$query="DELETE FROM hospital WHERE Id='$Id'";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Hospital has been Deleted.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
if(!empty($_GET))
{
$Id=$_GET['Id'];
$con1=connection();
$query="SELECT * FROM hospital WHERE Id = '$Id'";
$result1=mysqli_query($con1,$query);
$row1=mysqli_fetch_row($result1);
$location=explode(',',$row1[2]);
$location=implode(' ',$location);
echo "
<div id='regbox'>
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
<input type='hidden' name='Id' value='$Id'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='hospital_name' id='hospital_name' value='$row1[1]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       Location :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location' value='$location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Number of Beds :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='bed_number' id='bed_number' value='$row1[3]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Kind of Bed :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='bed_kind[]' id='bed_kind' value='$row1[4]'>
                </div>
            </div>			
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Facilities Available :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='facilities' id='facilities' value='$row1[5]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      No. of OPD Unit :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='no_of_opd_unit' id='no_of_opd_unit' value='$row1[6]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Name of Owner :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='owner_name' id='owner_name' value='$row1[7]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Contact Details :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts' id='contacts' value='$row1[8]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Email :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='email' id='email' value='$row1[9]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Year of Establishment :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='year_of_establishment' id='year_of_establishment' value='$row1[10]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Insurance Company :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company' id='insurance_company' value='$row1[11]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Average Turnover :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='average_turnover' id='average_turnover' value='$row1[12]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average bed occupancy :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <input type='text' name='bed_occupancy' id='bed_occupancy' value='$row1[13]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average rate of differnt beds :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <input type='text' name='average_rate_of_beds' id='average_rate_of_beds' value='$row1[14]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Any Other :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='any_other' id='any_other' value='$row1[15]'>
                </div>
            </div>
<button class='btn primary-bg medium'>
            <span class='button-content'>Delete</span>
        </button>
</form>
</div>";
}
echo "
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
