<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/
error_reporting(0);
require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');

echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Add Doctor
    <small>
        Add New Doctor
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_POST))
{
if(empty($_FILES['thefile']['tmp_name']))
$name="demo.jpg";
else	
$name=upload();	
$Name=$_POST['doctor_name'];	
$clinics=$_POST["clinic"];
$organisations=$_POST["organisation"];
$organisation=implode(',','$organisation');
if(isset($_POST['avg_patient_seen']))
$avg_patient_seen=$_POST['avg_patient_seen'];
else
$avg_patient_seen=0;
$hospital_names=$_POST["hospital_name"];
$qualification=$_POST['qualification'];
$mobile_number=$_POST['mobile_number'];
$email=$_POST['email'];
if(isset($_POST['dob']))
$dob=$_POST['dob'];
else
$dob=date('Y-m-d');
$any_other=$_POST['any_other'];
$specialisations=$_POST["specialisation"];
$specialisation=implode(',',$specialisations);
$locations=$_POST["location"];
$hospital_timings_from=$_POST["hospital_timing_from"];
$hospital_timing_from=implode(',',$hospital_timings_from);
$hospital_timings_to=$_POST["hospital_timing_to"];
$hospital_timing_to=implode(',',$hospital_timings_to);
$clinic_timings_to=$_POST["clinic_timing_to"];
$clinic_timing_to=implode(',',$clinic_timings_to);
$clinic_timings_from=$_POST["clinic_timing_from"];
$clinic_timing_from=implode(',',$clinic_timings_from);
$location=implode(',',$locations);
$hospital_name=implode(',',$hospital_names);
$clinic=implode(',',$clinics);
$con=connection();

$query="INSERT INTO doctor (Name, clinic, clinic_timing_from, clinic_timing_to, organisation, specialisation, avg_patient_seen, hospital_name, hospital_timing_from, hospital_timing_to, qualification, mobile_number, email, dob, location, any_other, picture) VALUES ('$Name', '$clinic', '$clinic_timing_from', '$clinic_timing_to', '$organisation', '$specialisation', '$avg_patient_seen', '$hospital_name', '$hospital_timing_from', '$hospital_timing_to', '$qualification', '$mobile_number', '$email', '$dob', '$location', '$any_other', '$name')";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Doctor has been added.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>
                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
echo "
<div id='regbox'>
<form action='".$_SERVER['PHP_SELF']."' method='post' enctype='multipart/form-data'>
     
	        <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                       Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='doctor_name' id='doctor_name'>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                        Specialisation:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='specialisation[]' id='specialisation'>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                        
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='specialisation[]' id='specialisation'>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                       
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='specialisation[]' id='specialisation'>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                        
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='specialisation[]' id='specialisation'>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Patients'>
                       Average no. of Patient seen :
                    </label>
                </div>
                <div class='form-checkbox-radio col-md-5'>
                            <div class='checkbox-radio'>
                                <input type='radio' name='avg_patient_seen' value='1'>
                                <label for=''>less than 10</label>
                            </div>
                            <div class='checkbox-radio'>
                                <input type='radio' name='avg_patient_seen' value='2'>
                                <label for=''>10-30</label>
                            </div>
                              <div class='checkbox-radio'>
                                <input type='radio' name='avg_patient_seen' value='3'>
                                <label for=''>30-50</label>
                            </div>
							  <div class='checkbox-radio'>
                                <input type='radio' name='avg_patient_seen' value='4'>
                                <label for=''>greater than 50</label>
                            </div>
                        </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                        Hospital:
                    </label>
                </div>
                <div class='form-input col-md-3'>
                 <select data-placeholder='Choose Hospital' class='chosen-select' name='hospital_name[]'>
                        <option value=''></option>";
						$con=connection();
						$query="SELECT DISTINCT Name FROM hospital";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}
                    echo "
					</select>
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-3'>
                 <select data-placeholder='Choose Hospital' class='chosen-select' name='hospital_name[]'>
                        <option value=''></option>";
						$con=connection();
						$query="SELECT DISTINCT Name FROM hospital";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}
                    echo "
					</select>
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                       
                    </label>
                </div>
                <div class='form-input col-md-3'>
                 <select data-placeholder='Choose Hospital' class='chosen-select' name='hospital_name[]'>
                        <option value=''></option>";
						$con=connection();
						$query="SELECT DISTINCT Name FROM hospital";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}
                    echo "
					</select>
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-3'>
                 <select data-placeholder='Choose Hospital' class='chosen-select' name='hospital_name[]'>
                        <option value=''></option>";
						$con=connection();
						$query="SELECT DISTINCT Name FROM hospital";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}
                    echo "
					</select>
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-3'>
                 <select data-placeholder='Choose Hospital' class='chosen-select' name='hospital_name[]'>
                        <option value=''></option>";
						$con=connection();
						$query="SELECT DISTINCT Name FROM hospital";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}
                    echo "
					</select>
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='hospital_timing_to[]' id=''> 
                </div>
				</div>				
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                        Clinic :
                    </label>
                </div>
                <div class='form-input col-md-3'>

                    <select name='clinic[]' data-placeholder='Choose Clinic' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM clinic";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}         
					
					echo "		  
                    </select>
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                      
                    </label>
                </div>
                <div class='form-input col-md-3'>

                    <select name='clinic[]' data-placeholder='Choose Clinic' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM clinic";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}         
					
					echo "		  
                    </select>
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                       
                    </label>
                </div>
                <div class='form-input col-md-3'>

                    <select name='clinic[]' data-placeholder='Choose Clinic' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM clinic";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}         
					
					echo "		  
                    </select>
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                      
                    </label>
                </div>
                <div class='form-input col-md-3'>

                    <select name='clinic[]' data-placeholder='Choose Clinic' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM clinic";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}         
					
					echo "		  
                    </select>
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_to[]' id=''> 
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                      
                    </label>
                </div>
                <div class='form-input col-md-3'>

                    <select name='clinic[]' data-placeholder='Choose Clinic' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM clinic";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}         
					
					echo "		  
                    </select>
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_from[]' id=''> 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>
                <input type='text' name='clinic_timing_to[]' id=''> 
                </div>
				</div>																
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        Organisation :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                       
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                       
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <select name='organisation[]' data-placeholder='Choose Organisation' class='chosen-select'>
                        <option value=''></option>";
						$query="SELECT DISTINCT Name FROM organisation";
						$result=mysqli_query($con,$query);
						while($row=mysqli_fetch_array($result))
						{
						echo "
                             <option  value='".$row['Name']."'>".$row['Name']."</option>";
						}      		
                    echo "      
                    </select>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Qualification :</label>
                </div>				
   <div class='form-input col-md-5'>
                    <input type='text' name='qualification'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Mobile Number :</label>
                </div>				
   <div class='form-input col-md-5'>
                   <input type='text' name='mobile_number'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Email :</label>
                </div>				
   <div class='form-input col-md-5'>
                   <input type='text' name='email'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Birthday :</label>
                </div>				
   <div class='form-input col-md-5'>
                  <input type='date' name='dob' value='12-07-2014' required='required'/>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Location :</label>
                </div>				
   <div class='form-input col-md-5'>
                <input type='text' name='location[]'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label></label>
                </div>				
   <div class='form-input col-md-5'>
                <input type='text' name='location[]'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label></label>
                </div>				
   <div class='form-input col-md-5'>
                <input type='text' name='location[]'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label></label>
                </div>				
   <div class='form-input col-md-5'>
                <input type='text' name='location[]'  />
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label></label>
                </div>				
   <div class='form-input col-md-5'>
                <input type='text' name='location[]'  />
                </div>
				</div>		
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Upload a Picture</label>
                </div>				
   <div class='form-input col-md-5'>
               <input type='hidden' name='MAX_FILE_SIZE' value='500000' />Select a File (Maximum Size 500 kb):<br />
<input type='file' name='thefile'>
                </div>
				</div>					
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Any Other :</label>
                </div>				
   <div class='form-input col-md-5'>
               <input type='text' name='any_other'  />
                </div>
				</div>
		<button class='btn primary-bg medium'>
		
            <span class='button-content'>Save</span>
        </button>
</div>
</form>

</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";
?>
