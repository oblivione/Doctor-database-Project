<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Add Hospital
    <small>
        Add the Hospital
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_POST))
{
$hospital_name=$_POST['hospital_name'];	
$location=$_POST["location"];
$bed_number=$_POST["bed_number"];
$bed_number=implode(" ",$bed_number);
$bed_kind=$_POST["bed_kind"];
$facilities=$_POST["facilities"];
$facilities=implode(" ",$facilities);
$no_of_opd_unit=$_POST['no_of_opd_unit'];
$owner_name=$_POST['owner_name'];
$contacts=$_POST['contacts'];
$email=$_POST['email'];
$year_of_establishment=$_POST['year_of_establishment'];
$insurance_company=$_POST["insurance_company"];
$insurance_company=implode(" ",$insurance_company);
$average_turnover=$_POST['average_turnover'];
$bed_occupancy=$_POST['bed_occupancy'];
$average_rate_of_beds=$_POST["average_rate_of_beds"];
$average_rate_of_beds=implode(" ",$average_rate_of_beds);
$any_other=$_POST['any_other'];
$locations=implode(' ',$location);
$bed_kinds=implode(' ',$bed_kind);
if(empty($_FILES['thefile']['tmp_name']))
$name="demo2.jpg";
else
$name=upload();
$con=connection();
$query="INSERT INTO hospital (Name, location, bed_numbers, kind_of_bed, facilities_available, opd_unit, owner_name, contact_details, email, year_of_establishment, insurance_company, average_turnover, average_bed_occupancy, average_rate, any_other, Picture) VALUES ('$hospital_name', '$locations', '$bed_number', '$bed_kinds', '$facilities', '$no_of_opd_unit', '$owner_name', '$contacts', '$email', '$year_of_establishment', '$insurance_company', '$average_turnover', '$bed_occupancy', '$average_rate_of_beds', '$any_other', '$name')";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Hospital has been added.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
echo "
<div id='regbox'>
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post' enctype='multipart/form-data'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='hospital_name' id='hospital_name'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       Location :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Number of Beds :
                    </label>
                </div>
                <div class='form-input col-md-6'>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      MEDICAL ICU :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      SURGICAL ICU :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
                <div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      CORONARY CARE UNIT :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      HIGH DEPENDENCY UNIT :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      NEONATAL ICU :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      PEDIATRIC ICU :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      BURN WARD (ICU) :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      DIALYSIS :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                     GENERAL BEDS :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      TWIN SHARING :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      LDRP :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      DELUXE SINGLE :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      SUPER DELUXE SINGLE :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      VIP SUITE :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      CASUALITY  :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				<div class='form-row'>
				<div class='form-label col-md-5'>
                    <label for='Location'>
                      DAY CARE  :
                    </label>
                </div>
				<div class='form-input col-md-3'>
                <input type='text' name='bed_number[]' id='bed_number'>
                </div>
				</div>
				</div>
            </div>

<input type='hidden' name='bed_kind[]' id='bed_kind' value='Not Available'>		
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Facilities Available :
                    </label>
                </div>
                <div class='form-input col-md-6'>
				CLINICAL DEPARTMENT
				<div class='form-checkbox-radio col-md-6'>
				<br>
				1.	Critical care department
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Emergency'>
                                <label for=''>A. Emergency /casualty</label>
                            </div>
							B. Intensive care unit (ICU)
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Medical ICU'>
                                <label for=''>Medical  ICU</label>
                            </div>
                              <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Surgical ICU'>
                                <label for=''>Surgical  ICU</label>
                            </div>
							  <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Burn centre'>
                                <label for=''>Burn centre</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Coronary Care Unit'>
                                <label for=''>Coronary Care Unit</label>
                            </div>
                        </div>
						<div class='form-checkbox-radio col-md-6'>
                            <div class='checkbox-radio'>
							C. High dependency unit (HDU)
                                <input type='checkbox' name='facilities[]' id='facilities' value='Medical HDU'>
                                <label for=''>Medical HDU</label>
                            </div>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Surgical HDU'>
                                <label for=''>Surgical HDU</label>
                            </div>
                              <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Neonatal Intensive care unit(NICU)'>
                                <label for=''>D. Neonatal Intensive care unit</label>
                            </div>
							  <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pediatric Intensive care unit(PICU)'>
                                <label for=''>E. Pediatric Intensive care unit</label>
                            </div>
                        </div>
                </div>
            </div>							
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				OT complex department
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Main OT complex '>
                                <label for=''>A. Main OT complex </label>
                            </div>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Emergency OT'>
                                <label for=''>B. Emergency OT</label>
                            </div>
                              <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Minor OT'>
                                <label for=''>C. Minor OT</label>
                            </div>
                        </div>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-8'>
				<div class='form-checkbox-radio col-md-8'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Cardiac cath lab(cardiology department)'>
                                <label for=''>Cardiac cath lab(cardiology department)</label>
                            </div>
                        </div>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				Gynecology  department
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Labour room'>
                                <label for=''>Labour room</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Labour OT'>
                                <label for=''>Labour OT</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pre partum observation room'>
                                <label for=''>Pre partum observation room</label>
                            </div>
                        </div>
					<div class='form-checkbox-radio col-md-6'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Post partum observation room'>
                                <label for=''>Post partum observation room</label>
                            </div>
                        </div>	
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				Pediatric department
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='NICU'>
                                <label for=''>NICU</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='PICU'>
                                <label for=''>PICU</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Play Room'>
                                <label for=''>Play Room</label>
                            </div>
                        </div>
					<div class='form-checkbox-radio col-md-6'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Immunization room'>
                                <label for=''>Immunization room</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Nursery'>
                                <label for=''>Nursery</label>
                            </div>
                        </div>	
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-8'>
				<div class='form-checkbox-radio col-md-8'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='General Surgery'>
                                <label for=''>6. General Surgery</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Orthopedics'>
                                <label for=''>7. Orthopedics</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='ENT'>
                                <label for=''>8. ENT</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Ophthalomology'>
                                <label for=''>9. Ophthalomology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Neurosurgery'>
                                <label for=''>10. Neurosurgery</label>
                            </div>
                        </div>				
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				O.P.D
				<div class='form-checkbox-radio col-md-6'>
				<br>
				Specialist department
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Medicine'>
                                <label for=''>Medicine</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pediatrics'>
                                <label for=''>Pediatrics</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Skin'>
                                <label for=''>Skin</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Psychiatry'>
                                <label for=''>Psychiatry</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pulmonology'>
                                <label for=''>Pulmonology</label>
                            </div>
                        </div>
					<div class='form-checkbox-radio col-md-6'>
					<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='OBS Gynecology'>
                                <label for=''>OBS Gynecology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='General surgery'>
                                <label for=''>General surgery</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='ENT'>
                                <label for=''>ENT</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Ophthalmology'>
                                <label for=''>Ophthalmology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Orthopedic'>
                                <label for=''>Orthopedic</label>
                            </div>
                        </div>	
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				O.P.D
				<div class='form-checkbox-radio col-md-6'>
				<br>
				Super Specialist department
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Cardiology'>
                                <label for=''>Cardiology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Neurology'>
                                <label for=''>Neurology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Neurosurgery'>
                                <label for=''>Neurosurgery</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Nephrology'>
                                <label for=''>Nephrology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Urology'>
                                <label for=''>Urology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Gastroenterology'>
                                <label for=''>Gastroenterology</label>
                            </div>
                        </div>
					<div class='form-checkbox-radio col-md-6'>
					<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Endocrinology'>
                                <label for=''>Endocrinology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Cosmetology'>
                                <label for=''>Cosmetology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Oncology'>
                                <label for=''>Oncology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Plastic surgery'>
                                <label for=''>Plastic surgery</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Rheumatology'>
                                <label for=''>Rheumatology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Vascular surgery'>
                                <label for=''>Vascular surgery</label>
                            </div>
                        </div>	
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				O.P.D
				<div class='form-checkbox-radio col-md-6'>
				<br>
				Special clinics
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Diabetic clinic'>
                                <label for=''>Diabetic clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Dental clinic'>
                                <label for=''>Dental clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Skin clinic'>
                                <label for=''>Skin clinic</label>
                            </div>
                        </div>
					<div class='form-checkbox-radio col-md-6'>
					<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Eye clinic'>
                                <label for=''>Eye clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='stem cell clinic'>
                                <label for=''>Stem cell clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Child Guidance clinic'>
                                <label for=''>Child Guidance Clinic</label>
                            </div>
                        </div>	
                </div>
            </div>	
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-8'>
				<div class='form-checkbox-radio col-md-8'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Medicine department'>
                                <label for=''>12. Medicine department</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Skin department'>
                                <label for=''>13. Skin department</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Psychiatric'>
                                <label for=''>14. Psychiatric</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Dental'>
                                <label for=''>15. Dental</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Chest department'>
                                <label for=''>16. Chest department</label>
                            </div>
                        </div>				
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				17. Gastroenterology
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Endoscopy'>
                                <label for=''>Endoscopy</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Colonoscopy'>
                                <label for=''>Colonoscopy</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Scelerotherapy'>
                                <label for=''>Scelerotherapy</label>
                            </div>
                        </div>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				18.	Nephrology Dialysis
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Dialysis'>
                                <label for=''>Dialysis</label>
                            </div>
                        </div>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				19.	Oncology Department
				<div class='form-checkbox-radio col-md-6'>
				<br>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Chemotherapy Unit'>
                                <label for=''>Chemotherapy Unit</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Radiotherapy Unit'>
                                <label for=''>Radiotherapy Unit</label>
                            </div>
                        </div>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      
                    </label>
                </div>
                <div class='form-input col-md-6'>
				20.	Alternative Medicine & Others 
				<div class='form-checkbox-radio col-md-6'>
				<br>
				A. Conventional
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Homeopathy Clinic'>
                                <label for=''>Homeopathy Clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Ayurvedic Clinic'>
                                <label for=''>Ayurvedic Clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Unani Clinic'>
                                <label for=''>Unani Clinic</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Siddha Clinic'>
                                <label for=''>Siddha Clinic</label>
                            </div>
                        </div>
				<div class='form-checkbox-radio col-md-6'>
				B. Non Conventional
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Acupuncture'>
                                <label for=''>Acupuncture</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Acupressure'>
                                <label for=''>Acupressure</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Reiki'>
                                <label for=''>Reiki</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Yoga'>
                                <label for=''>Yoga</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Naturopathy'>
                                <label for=''>Naturopathy</label>
                            </div>
                        </div>		
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Hospital support services 
                    </label>
                </div>
                <div class='form-input col-md-8'>
				<div class='form-checkbox-radio col-md-5'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Blood Bank'>
                                <label for=''>1. Blood Bank</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pharmacy'>
                                <label for=''>2. Pharmacy</label>
                            </div>
							3. Radiology
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='C.T.Scan'>
                                <label for=''>1. C.T.Scan</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='M.R.I'>
                                <label for=''>2. M.R.I</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='U.S.G'>
                                <label for=''>3. U.S.G</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='X-Ray'>
                                <label for=''>4. X-Ray</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Mammography'>
                                <label for=''>5. Mammography</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='B.M.D'>
                                <label for=''>6. B.M.D</label>
                            </div>
							4. Lab Services
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pathology'>
                                <label for=''>1. Pathology</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Biochemistry'>
                                <label for=''>2. Biochemistry</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Micro Biology'>
                                <label for=''>3. Micro Biology</label>
                            </div>
							5. Cardiac Testing Unit
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='E.C.G'>
                                <label for=''>1. E.C.G</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='2D Echo'>
                                <label for=''>2. 2D Echo</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Sonography'>
                                <label for=''>3. Sonography</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='T.M.T'>
                                <label for=''>4. T.M.T</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='EEG,EMG'>
                                <label for=''>5. EEG,EMG</label>
                            </div>
                        </div>					
						<div class='form-checkbox-radio col-md-7'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Pulmonary Function Test'>
                                <label for=''>6. Pulmonary Function Test</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Nerve Conduction Studies'>
                                <label for=''>7.Nerve Conduction Studies</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Ambulance & Transport Services'>
                                <label for=''>8. Ambulance & Transport Services</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Laundry'>
                                <label for=''>9. Laundry</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Kitchen Services'>
                                <label for=''>10. Kitchen Services</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Mortuary (Morgue)'>
                                <label for=''>11. Mortuary (Morgue)</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='CSSD (Central Sterilization Department)'>
                                <label for=''>12. CSSD (Central Sterilization Department)</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Physiotherapy Unit'>
                                <label for=''>13. Physiotherapy Unit</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Central Store'>
                                <label for=''>14. Central Store</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Bio Waste Management Department'>
                                <label for=''>15. Bio Waste Management Department</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Library'>
                                <label for=''>16. Library</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Occupational Therapy'>
                                <label for=''>17. Physiotherapy/Occupational Therapy</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='EPABX'>
                                <label for=''>18. EPABX</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Medical Transcription Department'>
                                <label for=''>19. Medical Transcription Department</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Video Conferencing'>
                                <label for=''>20. Video Conferencing</label>
                            </div>
							<div class='checkbox-radio'>
                                <input type='checkbox' name='facilities[]' id='facilities' value='Audiometry'>
                                <label for=''>21. Audiometry</label>
                            </div>
                        </div>						
                </div>
            </div>																																																					
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      No. of OPD Unit :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='no_of_opd_unit' id='no_of_opd_unit'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Name of Owner :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='owner_name' id='owner_name'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Contact Details :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts' id='contacts'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Email :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='email' id='email'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Year of Establishment :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='year_of_establishment' id='year_of_establishment'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Insurance Company :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company[]' id='insurance_company'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                   
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company[]' id='insurance_company'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                    
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company[]' id='insurance_company'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company[]' id='insurance_company'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='insurance_company[]' id='insurance_company'>
                </div>
            </div>												
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Average Turnover :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='average_turnover' id='average_turnover'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average bed occupancy :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <input type='text' name='bed_occupancy' id='bed_occupancy'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average rate of differnt beds :
                    </label>
                </div>
                <div class='form-checkbox-radio col-md-5'>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='average_rate_of_beds[]' value='150'>
                                <label for=''>150</label>
                            </div>
                            <div class='checkbox-radio'>
                                <input type='checkbox' name='average_rate_of_beds[]' value='200'>
                                <label for=''>200</label>
                            </div>
                              <div class='checkbox-radio'>
                                <input type='checkbox' name='average_rate_of_beds[]' value='250'>
                                <label for=''>250</label>
                            </div>
							  <div class='checkbox-radio'>
                                <input type='checkbox' name='average_rate_of_beds[]' value='300'>
                                <label for=''>300</label>
                            </div>
                        </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='hcopy'>
                        Upload Picture :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='hidden' name='MAX_FILE_SIZE' value='500000' />Select a File (Maximum Size 500 kb):<br />
<input type='file' name='thefile'>
                </div>
            </div>				
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Any Other :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='any_other' id='any_other'>
                </div>
            </div>
<button class='btn primary-bg medium'>
            <span class='button-content'>Save</span>
        </button>

</form>
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
