<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>";
echo "
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Add Invoices
    <small>
        Add details of all Invocie
    </small>
</h3>
</div>
<div id='page-content'>
";
if(!empty($_POST))
{	
$vendor_name=$_POST['vendor_name'];	
$item_name=$_POST['item_name'];
$description=$_POST["description"];
$description=implode(" ",$description);
$price=$_POST['price'];
$date=$_POST['date'];
if(empty($_FILES['thefile']['tmp_name']))
$name="demo1.jpg";
else
$name=upload();	
$con=connection();
$query="INSERT INTO invoices (Vendor_Name, Item_Name, Description, Price, Date, Picture) VALUES ('$vendor_name','$item_name','$description','$price','$date','$name')";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Invoice has been added.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";

}
echo "
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post' enctype='multipart/form-data'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Vendor_Name'>
                        Vendor Name :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='vendor_name' id='vendor_name' onfocus='searchVendor()'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Item_Name'>
                        Item Name :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='item_name' id='item_name' onfocus='searchItems()'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
                     Description :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='description[]' id='description'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
               
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='description[]' id='description'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
               
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='description[]' id='description'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
               
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='description[]' id='description'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
               
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='description[]' id='description'>
                </div>
            </div>												
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
                        Price :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='price' id='price'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Description'>
                        Date :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='date' name='date' id='date'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='hcopy'>
                        Upload Hard Copy :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='hidden' name='MAX_FILE_SIZE' value='500000' />Select a File (Maximum Size 500 kb):<br />
<input type='file' name='thefile'>
                </div>
            </div>																		
<button class='btn primary-bg medium'>
<span class='button-content'>Add</span>
</button>
</form>			
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
