<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>";
echo "
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Add Products
    <small>
        Add details of Products
    </small>
</h3>
</div>
<div id='page-content'>
";
if(!empty($_POST))
{
$item_name=$_POST['item_name'];
$item_name= strtolower($item_name);
if(!(drug_check($item_name)))
{	
$con=connection();
$query="INSERT INTO drugs (Name) VALUES ('$item_name')";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Item has been added.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
else
echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Item Already Exists</p>
                </div>
            </div>
        </div>";
}
echo "
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='item_name' id='item_name'>
                </div>
            </div>
<button class='btn secondary-bg medium' onclick='addrow()'>
<span class='button-content'>Add Another Item</span>
</button>			
<button class='btn primary-bg medium'>
<span class='button-content'>Add</span>
</button>
</form>			
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
