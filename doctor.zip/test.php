<?php
if(!empty($_POST))
{
	function upload()
{
if(array_key_exists('thefile', $_FILES)) {

// Validate the uploaded file
if($_FILES['thefile']['size'] === 0 
|| empty($_FILES['thefile']['tmp_name'])) {
    echo("<p>No file was selected.</p>\r\n");
} else if($_FILES['thefile']['size'] > 1000000000) {
    echo("<p>The file was too large.</p>\r\n");
} else if($_FILES['thefile']['error'] !== UPLOAD_ERR_OK) {
    // There was a PHP error
    echo("<p>There was an error uploading.</p>\r\n");
} else {

// Create uploads directory if necessary
if(!file_exists('uploads')) mkdir('uploads');

// Move the file
if(move_uploaded_file($_FILES['thefile']['tmp_name'], 
'uploads/' . $_FILES['thefile']['name'])) {
    echo("<p>File uploaded successfully!</p>\r\n");
	return $_FILES['thefile']['name'];
} else {
    echo("<p>There was an error moving the file.</p>\r\n");
}

}

}
}
$name=upload();
echo "Hey".$name;
}
?>
<form name='newHospital' class='form-bordered' action='test.php' method='post'>
<input type='file' name='thefile'>
<input type='submit'>
</form>
