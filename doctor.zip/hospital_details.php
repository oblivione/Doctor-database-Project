<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Hospital Details
    <small>
        View Detials of Hospitals
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_GET))
{
$Id=$_GET['Id'];	
$con=connection();
$query="SELECT * FROM hospital WHERE Id = '$Id'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
echo "
<div id='regbox'>
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Picture :
                    </label>
                </div>
                <div class='form-input col-md-6'>";
				if($row[16]!=Null)
				$pic=$row[16];
				else $pic="demo2.jpg";
				echo "
                    <a href='uploads/$pic' target='_blank'><img src='uploads/$pic' style='height:100px;width:100px;'></a>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[1]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       Location :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[2]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Number of Beds :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[3]</h4>
                </div>
            </div>

<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Kind of Bed :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[4]</h4>
                </div>
            </div>	
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Facilities Available :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[5]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      No. of OPD Unit :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[6]</h4>
                </div>
            </div>";
			$con1=connection();
			$query1="SELECT * FROM doctor WHERE hospital_name = '$row[1]'";
			$result1=mysqli_query($con1,$query1);
			while($row1=mysqli_fetch_array($result1))
			{	
			echo "
			<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Doctor's Name
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4><a href='doctor_details.php?Id=".$row1['Id']."' target='_blank'>".$row1['Name']."</a></h4>
                </div>
            </div>
			";
			}
			echo "
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Name of Owner :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[7]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Contact Details :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[8]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Email :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[9]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Year of Establishment :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[10]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Insurance Company :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[11]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Average Turnover :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[12]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average bed occupancy :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <h4>$row[13]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Location'>
                     Average rate of differnt beds :
                    </label>
                </div>
                <div class='form-input col-md-5'>
                    <h4>$row[14]</h4>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Any Other :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[15]</h4>
                </div>
            </div>

</form>
";
}
echo "
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
