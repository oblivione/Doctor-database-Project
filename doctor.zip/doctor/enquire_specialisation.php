<?php
error_reporting(0);
$specialisation=$_GET['specialisation'];
echo $specialisation;
$my_data=mysql_real_escape_string($specialisation);
$con1 = mysqli_connect("localhost","root","m","project6") or die("Database Error");
$sql="SELECT DISTINCT specialisation FROM doctor WHERE specialisation LIKE '%$my_data%' ORDER BY specialisation";
$result = mysqli_query($con1,$sql);
 if($result)
 {
  while($row=mysqli_fetch_array($result))
  {
   echo $row['specialisation']."\n";
  }
 }
mysqli_close($con1);
?>