<?php
error_reporting(0);
$location=$_GET['location'];
$my_data=mysql_real_escape_string($location);
$con1 = mysqli_connect("localhost","root","m","project6") or die("Database Error");
$sql="SELECT DISTINCT location FROM doctor WHERE location LIKE '%$my_data%' ORDER BY location";
$result = mysqli_query($con1,$sql);
 if($result)
 {
  while($row=mysqli_fetch_array($result))
  {
   echo $row['location']."\n";
  }
 }
mysqli_close($con1);
?>