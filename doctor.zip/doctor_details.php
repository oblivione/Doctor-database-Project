<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');

echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Doctor Details
    <small>
        View all the details of Doctors
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_GET))
{
$con=connection();
$Id=$_GET['Id'];
$query="SELECT * FROM doctor WHERE Id = '$Id'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
$pic="demo.jpg";
echo "

<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
		    <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Picture :
                    </label>
                </div>
                <div class='form-input col-md-6'>";
				if($row[17]!=Null)
				$pic=$row[17];
				else $pic="demo.jpg";
				echo "
                    <img src='uploads/$pic' style='height:100px;width:100px;'>
                </div>
            </div>
		    <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        First Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[1] </h4>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                        Specialisation:
                    </label>
                </div>
                <div class='form-input col-md-6'>";
                 $specialisation=explode(',',$row[6]);
				for($i=0;$i<sizeof($specialisation);$i++)
				{
				echo "
                <h4>$specialisation[$i]</h4>
				";
				}
				echo "
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for='Patients'>
                       Average no. of Patient seen :
                    </label>
                </div>
                <div class='form-checkbox-radio col-md-5'>
                           <h4>";
						   if($row[7]==1) echo "less than 10";
						   else if($row[7]==2) echo "10 - 30";
						   else if($row[7]==3) echo "30 - 50";
						   else if($row[7]==4)echo "greater than 50";
						   echo 
						   "</h4>
                        </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                   <label for=''>
                        Hospital:
                    </label>
                </div>
                <div class='form-input col-md-3'>";
				$hospital=explode(',',$row[8]);
				for($i=0;$i<sizeof($hospital);$i++)
				{
				echo "
                <h4>$hospital[$i]</h4>
				
				";
				}
				echo "
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>";
                $hospital_timing_from=explode(',',$row[9]);
				for($i=0;$i<sizeof($hospital_timing_from);$i++)
				{
				echo "
                <h4>$hospital_timing_from[$i]</h4>
				
				";
				}
				echo " 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>";
                $hospital_timing_to=explode(',',$row[9]);
				for($i=0;$i<sizeof($hospital_timing_to);$i++)
				{
				echo "
                <h4>$hospital_timing_to[$i]</h4>
				";
				}
				echo "
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                    <label for=''>
                        Clinic :
                    </label>
                </div>
                <div class='form-input col-md-3'>";
				$clinic=explode(',',$row[2]);
				for($i=0;$i<sizeof($clinic);$i++)
				{
				echo "
                <h4>$clinic[$i]</h4>
				";
				}
				echo "
                </div>
				<div class='form-label col-md-1'>
                   <label for=''>
                        From :
                    </label>
                </div>
                <div class='form-input col-md-1'>";
                $clinic_timing_from=explode(',',$row[3]);
				for($i=0;$i<sizeof($clinic_timing_from);$i++)
				{
				echo "
                <h4>$clinic_timing_from[$i]</h4>
				";
				}
				echo " 
                </div>
				 <div class='form-label col-md-1'>
                   <label for=''>
                        To :
                    </label>
                </div>
                <div class='form-input col-md-1'>";
                $clinic_timing_to=explode(',',$row[4]);
				for($i=0;$i<sizeof($clinic_timing_to);$i++)
				{
				echo "
                <h4>$clinic_timing_to[$i]</h4>
				";
				}
				echo "
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label for=''>
                        Organisation :
                    </label>
                </div>
                <div class='form-input col-md-5'>";
				
                $clinic=explode(',',$row[5]);
				for($i=0;$i<sizeof($clinic);$i++)
				{
				echo "
                <h4>$clinic[$i]</h4>
				";
				}
				echo "   
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Qualification :</label>
                </div>				
   <div class='form-input col-md-5'>
                    <h4>$row[11]</h4>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Mobile Number :</label>
                </div>				
   <div class='form-input col-md-5'>
                   <h4>$row[12]</h4>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                 <label>Email :</label>
                </div>				
   <div class='form-input col-md-5'>
                   <h4>$row[13]</h4>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Birthday :</label>
                </div>				
   <div class='form-input col-md-5'>
                  <h4>$row[14]</h4>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Location :</label>
                </div>				
   <div class='form-input col-md-5'>";
                 $location=explode(',',$row[15]);
				 $location=implode(' ',$location);
				echo "
				 <h4>$location</h4>
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-3'>
                <label>Any Other :</label>
                </div>				
   <div class='form-input col-md-5'>
               <h4>$row[16]</h4>
                </div>
				</div>
</div>
</form>
";
}
echo "
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";
?>
