<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Edit Details of Vendors
    <small>
        Edit details of Vendors
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_POST))
{
$organisation_name=$_POST['organisation_name'];	
$location=$_POST["location"];
$facilities=$_POST['facilities'];
$owner_name=$_POST['owner_name'];
$contacts=$_POST["contacts"];
$email=$_POST['email'];
$year_of_establishment=$_POST['year_of_establishment'];
$average_turnover=$_POST['average_turnover'];
$any_other=$_POST['any_other'];
$Id=$_POST['Id'];
$locations=implode(' ',$location);
$contacts=implode(' ',$contacts);
$con=connection();
$query="UPDATE vendor SET Name='$organisation_name', location='$locations', facilities_available='$facilities', owner_name='$owner_name', contact_details='$contacts', email='$email', year_of_establishment='$year_of_establishment', average_turnover='$average_turnover', any_other='$any_other' WHERE Id='$Id'";
$a=mysqli_query($con,$query) ? true : false ;
if($a)
echo "
<div class='row'>
<div class='col-md-4'>

                <div class='infobox success-bg'>
                    <p>1 Vendor Details has been updated.</p>
                </div>
            </div>
			</div>
			";
else echo "
<div class='row'>
<div class='col-md-6'>

                <div class='infobox error-bg mrg0A'>
                    <p>Error Occured</p>
                </div>
            </div>
        </div>
		";
}
if(!empty($_GET))
{
$Id=$_GET['Id'];
$con1=connection();
$query="SELECT * FROM vendor WHERE Id = '$Id'";
$result1=mysqli_query($con1,$query);
$row1=mysqli_fetch_row($result1);
$location=explode(',',$row1[2]);
$location=implode(' ',$location);
$contact=explode(',',$row1[5]);
$contact=implode(' ',$contact);
echo "
<div id='regbox'>
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
<input type='hidden' name='Id' value='$Id'>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Name:
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='organisation_name' id='organisation_name' value='$row1[1]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                       Location :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='location[]' id='location' value='$location'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Facilities Available :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='facilities' id='facilities'  value='$row1[3]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                      Name of Owner :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='owner_name' id='owner_name'  value='$row1[4]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Contact Details :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='contacts[]' id='contacts[]' value='$contact'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Email :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='email' id='email'  value='$row1[6]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Year of Establishment :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='year_of_establishment' id='year_of_establishment'  value='$row1[7]'>
                </div>
            </div>

<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Average Turnover :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='average_turnover' id='average_turnover'  value='$row1[8]'>
                </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Location'>
                     Any Other :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <input type='text' name='any_other' id='any_other'  value='$row1[9]'>
                </div>
            </div>
<button class='btn primary-bg medium'>
            <span class='button-content'>Update</span>
        </button>

</form>
</div>
";
}
echo "
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
