<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/
require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Search Doctor
    <small>
        Search doctor by Name, Location and Specialisation
    </small>
</h3>
</div>
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content'>
<table class='table' id='example1'>
	<thead>
		<tr>
			<th>Name</th>
			<th>Location</th>
			<th>Specialist</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>";
	$con=connection();
	$query="SELECT * FROM doctor";
	$result=mysqli_query($con,$query);
	while($row=mysqli_fetch_array($result))
	{
	$specialisation=explode(',',$row['specialisation']);
	$specialisation=implode(' ',$specialisation);
	$location=explode(',',$row['location']);
	$location=implode(' ',$location);	
	echo "<tr>
<td><a href='doctor_details.php?Id=".$row['Id']."' target='_blank'>".$row['Name']."</a></td><td>".$location."</td><td>".$specialisation."</td>
<td>
<a href='edit_doctor.php?Id=".$row['Id']."' target='_blank' class='btn small bg-blue-alt tooltip-button' data-placement='top' title='Edit'>
                            <i class='glyph-icon icon-edit'></i>
                        </a>
                        <a href='delete_doctor.php?Id=".$row['Id']."' target='_blank' class='btn small bg-red tooltip-button' data-placement='top' title='Remove'>
                            <i class='glyph-icon icon-remove'></i>
                        </a>
</td>
</tr>";
	}
	echo "	
	</tbody>
	<tfoot>
		<tr>
			<th>Name</th>
			<th>Location</th>
			<th>Specialist</th>
			<th>Actions</th>
		</tr>
	</tfoot>
</table>
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
";


?>
