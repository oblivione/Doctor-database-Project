<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');
echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>";
echo "
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Quotations
    <small>
        Add details of Quotation
    </small>
</h3>
</div>
<div id='page-content'>
 <div class='row mrg20B'>

            <div class='col-lg-3'>

                <a href='add_drugs.php' target='_blank' class='tile-button btn bg-blue-alt' title=''>
                    <div class='tile-header'>
                       Add New Drugs
                    </div>
                    <div class='tile-content-wrapper'>
                        <i class='glyph-icon icon-dashboard'></i>
                        <div class='tile-content'>
                            Add a Drug
                        </div>
                        <small>
                            <i class='glyph-icon icon-caret-up'></i>
                           First you need to add products
                        </small>
                    </div>
                    <div class='tile-footer'>
                        Add
                        <i class='glyph-icon icon-arrow-right'></i>
                    </div>
                </a>

            </div>

            <div class='col-lg-3'>

                <a href='add_pharma_quotations.php' target='_blank' class='tile-button btn bg-green' title=''>
                    <div class='tile-header'>
                       Add New Quotations
                    </div>
                    <div class='tile-content-wrapper'>
                        <i class='glyph-icon icon-camera'></i>
                        <div class='tile-content'>
                            Add Quotation
                        </div>
                        <small>
                            <i class='glyph-icon icon-caret-up'></i>
                            Here you can add new Quotations
                        </small>
                    </div>
                    <div class='tile-footer'>
                        Add
                        <i class='glyph-icon icon-arrow-right'></i>
                    </div>
                </a>

            </div>


            <div class='col-lg-3'>

                <a href='view_pharma_quotations.php' target='_blank' class='tile-button btn bg-gray-alt' title=''>
                    <div class='tile-header'>
                        View Quotation Details
                    </div>
                    <div class='tile-content-wrapper'>
                        <i class='glyph-icon icon-bullhorn'></i>
                        <div class='tile-content'>
                           View Quotations
                        </div>
                        <small>
                            <i class='glyph-icon icon-caret-up'></i>
                           Here you can view and edit quotations
                        </small>
                    </div>
                    <div class='tile-footer'>
                        view details
                        <i class='glyph-icon icon-arrow-right'></i>
                    </div>
                </a>

            </div>
			</div>		
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";

?>
