<?php
/*
UserCake Version: 2.0.2
http://usercake.com
*/

require_once("models/config.php");
if (!securePage($_SERVER['PHP_SELF'])){die();}
require_once("models/header.php");
include('library.php');

echo "
<body> 
<div id='loading' class='ui-front loader ui-widget-overlay bg-white opacity-100'>
<img src='assets/images/loader-dark.gif' alt=''>
</div>
<div id='page-wrapper' class='demo-example'>";
include('models/topbar.php');
include("models/sidebar.php");
echo "
<div id='g10' class='small-gauge float-left hidden'></div>
<div id='g11' class='small-gauge float-right hidden'></div>
<div id='page-content-wrapper'>
<div id='page-title'>
<h3>Quotation Details
    <small>
        View all the details of Quotations
    </small>
</h3>
</div>
<div id='page-content'>";
if(!empty($_GET))
{
$con=connection();
$Id=$_GET['Id'];
$query="SELECT * FROM pharma_quotations WHERE Id = '$Id'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
$pic="demo.jpg";
echo "
<form name='newHospital' class='form-bordered' action='".$_SERVER['PHP_SELF']."' method='post'>
		    <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                        Picture :
                    </label>
                </div>
                <div class='form-input col-md-6'>";
				if($row[6]!=Null)
				$pic=$row[6];
				else $pic="demo1.jpg";
				echo "
                    <a href='uploads/$pic' target='_blank'><img src='uploads/$pic' style='height:100px;width:100px;'></a>
                </div>
            </div>
		    <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Name'>
                       Vendor Name :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                    <h4>$row[1] </h4>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Specialisation'>
                        Item Name :
                    </label>
                </div>
                <div class='form-input col-md-6'>
                <h4>$row[2]</h4>
                </div>
            </div>
			 <div class='form-row'>
                <div class='form-label col-md-2'>
                    <label for='Patients'>
                       Description :
                    </label>
                </div>
                <div class='form-checkbox-radio col-md-6'>
                           <h4>$row[3]</h4>
                        </div>
            </div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                   <label for=''>
                        Price :
                    </label>
                </div>
                <div class='form-input col-md-6'>
				$row[4]
                </div>
				</div>
<div class='form-row'>
                <div class='form-label col-md-2'>
                 <label>Date :</label>
                </div>				
   <div class='form-input col-md-6'>
                    <h4>".date('d-m-Y',strtotime($row[5]))."</h4>
                </div>
				</div>
</form>
";
}
echo "
</div><!-- #page-content -->
</div><!-- #page-main -->
</div><!-- #page-wrapper -->
</body>
</html>";
?>
